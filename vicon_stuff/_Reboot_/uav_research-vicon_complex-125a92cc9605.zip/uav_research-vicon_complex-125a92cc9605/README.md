# Full C++ code for sending VICON data out over a local network on a windows machine#

Make sure you link the vicon sdk in whatever IDE you are using.
Requires the vicon tracker to be running on the same machine once compiled.

Code explanation found at,
https://youtu.be/_hqxbYHTFug