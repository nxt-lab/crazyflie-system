void send_PVA_data(void) ;

int init_socket(void) ;

void close_socket(void) ;

void stoshort(short n, char *s) ;

void stoushort(unsigned short n, char* s) ;

void stouint(unsigned int n, char *s) ;

void stouint_reverse(unsigned int n, char *s) ;

void stoint(int n, char *s) ;

void stolong(long long int n, char *s) ;

void stodouble(double n, char *s) ;

void stofloat(float n, char *s) ;
